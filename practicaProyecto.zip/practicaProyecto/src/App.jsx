/* Usuarios:
Administrador: email "alejandrolluchsanchez@outlook.es" password "123456"
Authenticated: email "alejandroll16@hotmail.com" password "123456" */

//Faltaría verificar campos formulario de inicio sesión y crear cuenta, así como avisar si el correo ya existe.

import { Fragment } from "react";

import { BrowserRouter } from "react-router-dom";
import NavBar from "./Componentes/NavBar/NavBar";
import MainContent from "./Componentes/MainContent/ComponentesProductos/MainContent";
import ContextoProductos from "./Componentes/Contextos/ContextoProductos";
import PiePagina from "./Componentes/Pie/PiePagina";
import ContextoListas from "./Componentes/Contextos/ContextoListas.jsx";
import ContextoUsuarios from "./Componentes/Contextos/ContextoUsuarios";

function App() {
  return (
    <Fragment>
      <BrowserRouter>
        <ContextoUsuarios>
          <ContextoProductos>
            <ContextoListas>
              <NavBar />
              <MainContent />
              <PiePagina />
            </ContextoListas>
          </ContextoProductos>
        </ContextoUsuarios>
      </BrowserRouter>
    </Fragment>
  );
}

export default App;
