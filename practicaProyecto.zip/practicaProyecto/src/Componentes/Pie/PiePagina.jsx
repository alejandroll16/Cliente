import React from 'react'
import "./piePagina.css"

const PiePagina = () => {
  return (
    <div className='contenedorPie'>
        <p className='textoPie'>Todos los derechos reservados a LluchOcasión.SL &#169;.</p>
    </div>
  )
}

export default PiePagina