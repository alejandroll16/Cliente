import React, { Fragment } from "react";
import "./inicio.css"
import { Link } from "react-router-dom";

const Inicio = () => {
  return (
    <Fragment>
      <div className="contenedorInicio">
      <div className="bloqueInfoInicio" >
        <section className="HeroInicio" >
          <img className="imagenHeroInicio" src="https://motor.elpais.com/wp-content/uploads/2022/07/Human-Horizons-HiPhi-Z-4.jpg" alt="" />
        </section>
        <section className="InicioCrearSesion" >
          <h2>Únete a nosotros y encuentra tu coche ideal</h2>
        <Link className="botonCrearUserInicio" to="/FormCrearUsuario"  >Crear Usuario</Link>

        </section>
      </div>
      </div>
      
    </Fragment>
  );
};

export default Inicio;