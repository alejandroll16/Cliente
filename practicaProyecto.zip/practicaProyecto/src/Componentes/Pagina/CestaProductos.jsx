import React, { useContext, useState } from "react";
import ListaProductos from "../MainContent/ComponentesProductos/ListaProductos.jsx";
import SelectorOrden from "../MainContent/ComponentesFiltrado/SelectorOrden.jsx";
import BarraBusqueda from "../MainContent/ComponentesFiltrado/BarraBuscar.jsx";
import RangoPrecio from "../MainContent/ComponentesFiltrado/RangoPrecio.jsx";
import RangoPeso from "..//MainContent/ComponentesFiltrado/RangoPeso.jsx";
import  useProductos from "../Contextos/hooksContextos/useProductos.jsx";
import "./CestraProductos.css";

const CestaProductos = () => {
  const {
    cambiarOrden,
    filtrarProductos,
    productosFiltrados,
    setRangoPrecio,
    setRangoPeso,
    setOrden,
  } = useProductos();

    //Estados locales para usar los filtros y el botón de mostrar.
  const [aplicarFiltros, setAplicarFiltros] = useState(false);
  const [filtrosVisibles, setFiltrosVisibles] = useState(false); 

  
  //Función para ejecutar la búsqueda por término introducido.
  const usarBuscar = (termino) => {
    filtrarProductos(termino);
    setAplicarFiltros(false);
  };

  //Funciones para ejecutar filtros por rango de precio y peso.
  const onFiltrarPrecio = (nuevoRangoPrecio) => {
    setRangoPrecio(nuevoRangoPrecio);
    setAplicarFiltros(true);
  };

  const onFiltrarPeso = (nuevoRangoPeso) => {
    setRangoPeso(nuevoRangoPeso);
    setAplicarFiltros(true);
  };

  //Funciones para aplicar filtros por rango de precio y peso.
  const restaurarFiltros = () => {
    setRangoPrecio([1500000]);
    setRangoPeso([30000]);
    setAplicarFiltros(false);
    filtrarProductos("");
    cambiarOrden("nombre"); //Quiero el valor predeterminado por nombre no por el orden en la base de datos.
    setOrden(1); //Para que siempre que restauremos nos muestre por orden de la A a la Z.
  };

  const mostrarFiltros = () => {
    setFiltrosVisibles(!filtrosVisibles);
  };

  return (
    <div>
      <section id="info">
        <button className="mostrarFiltros" type="button" onClick={mostrarFiltros}>
          {filtrosVisibles ? "Ocultar Filtros" : "Mostrar Filtros"}
        </button>
        {filtrosVisibles && (
          <div className="contenedorFiltros">
            <BarraBusqueda buscar={usarBuscar} />
            <SelectorOrden orden={cambiarOrden} />
            <RangoPrecio precio={onFiltrarPrecio} />
            <RangoPeso peso={onFiltrarPeso} />
            <button className="botonRestaurar" type="button" onClick={restaurarFiltros}>
              Restaurar Filtros
            </button>
          </div>
        )}
                {/*Renderiza o muestra la lista de productos, aplicando filtros si los hay o no. */}
        <ListaProductos productos={aplicarFiltros ? productosFiltrados : undefined} />
      </section>
    </div>
  );
};

export default CestaProductos;
