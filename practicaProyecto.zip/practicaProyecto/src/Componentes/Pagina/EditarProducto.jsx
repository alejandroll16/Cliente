import React, { useContext, useEffect } from 'react';
import FormCreaMod from '../MainContent/ComponentesProductos/FormularioCreaMod.jsx';

const EditarProducto = () => {
  

  return (
    <div>
      <FormCreaMod />
    </div>
  );
};

export default EditarProducto;
