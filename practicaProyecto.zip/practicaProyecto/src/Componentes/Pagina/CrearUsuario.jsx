import React from 'react'
import FormCrearUsuario from '../MainContent/ComponentesUsuarios/FormCrearUsuario';

const CrearUsuario = () => {
  return (
    <div>
        <FormCrearUsuario/>
    </div>
  )
}

export default CrearUsuario;