import React from 'react';
import FormCreaMod from '../MainContent/ComponentesProductos/FormularioCreaMod.jsx';

const CrearProducto = () => {
  return (
    <div>
      <FormCreaMod />
    </div>
  );
};

export default CrearProducto;
