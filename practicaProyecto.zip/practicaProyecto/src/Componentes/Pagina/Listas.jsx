import React from 'react'
import ListadoListas from '../MainContent/ComponentesListas/ListadoListas.jsx'

const Listas = () => {
  return (
    <div>
      <ListadoListas/>
    </div>
  )
}

export default Listas