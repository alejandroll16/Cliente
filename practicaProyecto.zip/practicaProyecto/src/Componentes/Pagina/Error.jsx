import {Fragment} from 'react'

const Error = () => {
  return (
    <Fragment>
    <h1>Error</h1>
    <p>Lo siento chaval, mas suerte la próxima.</p>
    </Fragment>
  )
}

export default Error