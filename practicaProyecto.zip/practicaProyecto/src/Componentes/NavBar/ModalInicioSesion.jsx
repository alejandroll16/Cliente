import "../NavBar/modalInicioSesion.css";
import React from "react";
import { Link } from "react-router-dom";

import useUsuarios from "../../Componentes/Contextos/hooksContextos/useUsuarios.jsx";

const ModalInicioSesion = () => {
  const { actualizarDato, iniciarSesion, setMostrarIniciarSesion } =
    useUsuarios();

  return (
    <div className="IniciarSesion">
      <div className="formularioInicioSesion">
        <div
          className="botonCerrarInicioSesion"
          onClick={() => {

            setMostrarIniciarSesion(false);
          }}
        >
          &times;
        </div>
        <h2>Iniciar sesión</h2>

        <form>
          <label>
            <input
              type="email"
              name="email"
              id="email"
              placeholder="Correo electrónico"
              onChange={(e) => {
                actualizarDato(e);
              }}
            />
          </label>
          <br />
          <label>
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Contraseña"
              onChange={(e) => {
                actualizarDato(e);
              }}
            />
          </label>
          <br />
          <div className="contenedorBotonesInicio">
            <button
              className="botonIniciar"
              onClick={(e) => {
                /* Ejecutamos la función iniciarSesion y pasamos a false el estado para que deje de mostrarse. */
                e.preventDefault();
                iniciarSesion();
                setMostrarIniciarSesion(false);
              }}
            >
              Iniciar Sesión
            </button>

            <p className="avisoNoCuenta">
              ¿No tienes una cuenta? Haz click aquí
            </p>

            <Link
              className="botonCrearUser"
              to="/FormCrearUsuario"
              onClick={() => setMostrarIniciarSesion(false)}
            >
              Crear Usuario
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ModalInicioSesion;
