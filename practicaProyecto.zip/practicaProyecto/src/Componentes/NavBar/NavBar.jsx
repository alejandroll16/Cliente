import React from "react";
import { Link } from "react-router-dom";
import "./navBar.css";
import useUsuarios from "../../Componentes/Contextos/hooksContextos/useUsuarios.jsx";
import ModalInicioSesion from "./ModalInicioSesion";

const NavBar = () => {
  const { mostrarIniciarSesion, setMostrarIniciarSesion, usuario, sesionIniciada, cerrarSesion } =
    useUsuarios();


  const useInicioSesion = () => {
    setMostrarIniciarSesion(true);
  };

  const cancelarInicioSesion = () => {
    setMostrarIniciarSesion(false);
  };

  const confirmarIniciarSesion = async () => {
    setMostrarIniciarSesion(false);
  };


  //Ha razón de si la sesión está iniciada o no se muestrar el botón de inicir sesión o de cerrarla.
  const modificarBotonInicio = () => {
    if (sesionIniciada) {
      cerrarSesion();
    } else {
      useInicioSesion();
    }
  };


  return (
    <div className="contenedorNav">
      <section>
        <h1 className="titulo">LluchOcasión</h1>
      </section>
      <section className="contenedorEnlaces">
        <nav className="enlaces">
          <Link className="link" to="/">
            Inicio
          </Link>
          <Link to="/ListaProductos">Vehículos</Link>
          {sesionIniciada && usuario.role === "administrador" && (
            <Link to="/FormCreaMod">Añadir vehículo</Link>
          )}
          {/* Así es como he ocultado o mostrado los botones en razón al rol del usuario, comprobamos si la sesión está iniciada y luego si es igual al rol que le pasemos se mostrará el link o button correspondiente.*/}
          {sesionIniciada && (usuario.role === "administrador" || usuario.role === "authenticated") && (
            <Link className="link" to="/ListadoListas">
              Mis listas
            </Link>
          )}

          {/* Ternaria para mostrar iniciarSesion o cerrar. */}
          <button id="InicioSesion" onClick={modificarBotonInicio}>
            {sesionIniciada ? "Cerrar sesión" : "Iniciar sesión"}
          </button>
        </nav>
      </section>
      {mostrarIniciarSesion && (
        <ModalInicioSesion
          cancelarInicioSesion={cancelarInicioSesion}
          confirmarIniciarSesion={confirmarIniciarSesion}
          setMostrarIniciarSesion={setMostrarIniciarSesion}
        />
      )}
    </div>
  );
};

export default NavBar;
