import React, { useState } from "react";
import useUsuarios from "../../Contextos/hooksContextos/useUsuarios.jsx";
import "./formCrearUsuario.css";

const FormCrearUsuario = () => {
  const { crearCuenta, actualizarDato } = useUsuarios();

  //Estado para controlar que se muestre el mensaje.
  const [mostrarMensaje, setMostrarMensaje] = useState(false);

  //Función para manejar el botón de crear cuenta, para que al crearla muestre el mensaje de que revise el email.

  const manejarCrearCuenta = (e) => {
    e.preventDefault();
    crearCuenta(e);
    setMostrarMensaje(true); // Mostrar el mensaje después de crear la cuenta
  };

  return (
    <div className="contenedorPrincipalCrear">
      <div className="contenedorFormularioCrea">
        <h2>Crea tu usuario</h2>
        <form className="grupoFormulario">
          <label>
            <input
              type="email"
              name="email"
              id="email"
              placeholder="Correo electrónico"
              onChange={(e) => {
                actualizarDato(e);
              }}
            />
          </label>
          <br />
          <label>
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Contraseña"
              onChange={(e) => {
                actualizarDato(e);
              }}
            />
          </label>
          <br />
          <button className="botonCrearCuenta"
            type="submit"
            onClick={(e) => {
              manejarCrearCuenta(e);


            }}
          >
            Crear cuenta
          </button>
        </form>
        {mostrarMensaje && ( // Mostrar el mensaje si mostrarMensaje es verdadero
          <p>Recibirás un correo para la confirmación de la cuenta.</p>
        )}

      </div>
    </div>
  );
};

export default FormCrearUsuario;
