import React, { useContext, useEffect, useState } from "react";
import useListas  from "../../Contextos/hooksContextos/useListas.jsx";
import EliminarProductoLista from ".//EliminarProductoLista.jsx";
import "./productosListas.css";

const ProductosLista = ({ codigoLista }) => {
  const {
    productosPorLista,
    eliminarProductoLista,
    showEliminarProductoLista,
    setShowEliminarProductoLista,
    productoAEliminarLista,
    setProductoAEliminarLista,
  } = useListas();
  const [totalPrecio, setTotalPrecio] = useState(0);
  const [totalPeso, setTotalPeso] = useState(0);
  const [mensajePeso, setMensajePeso] = useState("");
  
  //Ejecutamos el useEffect cada vez que productosPorLista cambia, ya que varía cada vez que se actúa sobre los productos de la lista lo he usado en el useEffect.
  useEffect(() => {
        //Verifica si no hay productos o la lista está vacía, si es así se muestra el mensaje de que no hay productos.
    if (!productosPorLista || productosPorLista.length === 0) {
      setTotalPrecio(0);
      setTotalPeso(0);
      setMensajePeso("No hay productos en la lista");
    } else {
            //Reciclamos la lógica que usábamos en el precio medio en la lista de Productos.
      const sumaPrecios = productosPorLista.reduce(
        (total, producto) => {
          return total + producto.tablaProducto.precio * producto.cantidadProductos;
        },
        0
      );
      setTotalPrecio(sumaPrecios);

      const precioTotalConCantidad = sumaPrecios * productosPorLista.reduce((total, producto) => {
        return total + (producto.cantidadProductos || 0);
      }, 0);
      setTotalPrecio(precioTotalConCantidad);
  
      const sumaPeso = productosPorLista.reduce(
        (total, producto) => {
          return total + producto.tablaProducto.peso * producto.cantidadProductos;
        },
        0
      );
      setTotalPeso(sumaPeso);

      const pesoTotalConCantidad = sumaPeso * productosPorLista.reduce((total, producto) => {
        return total + (producto.cantidadProductos || 0);
      }, 0);
      setTotalPeso(pesoTotalConCantidad);

      //En caso de que sumaPeso sea mayor o igual a 10000 se le pasa un mensaje al cliente si no se pasará otro mensaje, usamos un estado para esto.
      setMensajePeso(
        pesoTotalConCantidad  >= 10000
          ? "¡El peso excede lo permitido, se abonará un extra de 1500€ al precio para el envío de los vehículos!"
          : "El peso entra en los márgenes para el envío ordinario del vehículo."
      );
    }
  }, [productosPorLista]);
  
  
  //Misma lógica que he usado para mostrar eliminar producto en la lista de productos.
  const mostrarConfirmacionEliminar = (codigoProducto) => {
    setProductoAEliminarLista(codigoProducto);
    setShowEliminarProductoLista(true);
  };

  const cancelarEliminar = () => {
    setProductoAEliminarLista(null);
    setShowEliminarProductoLista(false); 
  };

  const confirmarEliminar = async (codigoProducto) => {
    await eliminarProductoLista(codigoProducto, codigoLista);
    setProductoAEliminarLista(null);
    setShowEliminarProductoLista(false);
  };

  return (
    <div className="contenedorProductoLista">
      {/* Si productosPorLista está vacío se mostrará un mensaje de que no hay productos en la lista. */}
      {productosPorLista && productosPorLista.length > 0 ? (
        <div className="cosa">
          <div className="containerProductosLista">
            <div>
              {productosPorLista.map((producto, indice) => (
                <div className="productoLista" key={indice}>
                  <div className="nombreImagenProducto">
                    <p>{producto.tablaProducto.nombre}</p>
                    <img
                      className="imagenProductoLista"
                      src={producto.tablaProducto.imagen}
                      alt={`Imagen de ${producto.tablaProducto.nombre}`}
                      style={{ maxWidth: "100%" }}
                    />
                  </div>
                  <div className="precioPesoProducto">
                    <p>precio: {(producto.tablaProducto.precio) * producto.cantidadProductos} €</p>
                    <p>peso: {(producto.tablaProducto.peso) * producto.cantidadProductos} Kg</p>
                    <p>cantidad: {(producto.cantidadProductos)}</p>
                  </div>

                  <div
                    className="botonEliminarProductoLista"
                    onClick={() => {
                      const codigoProducto = producto.tablaProducto.codigo;
                      mostrarConfirmacionEliminar(codigoProducto);
                    }}
                  >
                    &times;
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="contenedorResumenLista">
            <p>Total Precio: {totalPrecio} €</p>
            <p>Total Peso: {totalPeso} Kg</p>
            <p>{mensajePeso}</p>
          </div>
          
          {showEliminarProductoLista && (
            <EliminarProductoLista
              codigoProducto={productoAEliminarLista}
              cancelarEliminar={cancelarEliminar}
              confirmarEliminar={confirmarEliminar}
            />
          )}
        </div>
      ) : (
        <p className="mensajeProductos">No hay productos en la lista...</p>
      )}
    </div>
  );
};

export default ProductosLista;
