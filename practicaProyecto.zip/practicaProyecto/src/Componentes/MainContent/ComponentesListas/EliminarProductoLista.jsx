//Coomponente modal, se pasa por parámetro las propiedades necesarias para poder elimnar el producto de la lista desde el modal.
const EliminarProductoLista = ({ codigoProducto, cancelarEliminar, confirmarEliminar, }) => {



  return (
    <div className="confirmarEliminar">
      <div className="contenidoEliminar">
        <p>¿Seguro que quieres eliminar este producto de la lista?</p>
        <div className="botonesConfirmar">
          <button
            className="botonEliminarProducto"
            //Pasamos el código del producto a eliminar.
            onClick={() => confirmarEliminar(codigoProducto)}
          >
            Confirmar
          </button>
          <button
            className="botonEliminarProducto"
            onClick={cancelarEliminar}
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
};

export default EliminarProductoLista;
