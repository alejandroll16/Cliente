import React, { useContext, useState } from "react";
import useListas  from "../../Contextos/hooksContextos/useListas.jsx";
import ProductosLista from "./ProductosListas.jsx";
import "./listadoListas.css";

const ListadoListas = () => {
  const {
    listas,
    obtenerProductosPorLista,
    showForm,
    setShowForm,
    nuevaListaNombre,
    setNuevaListaNombre,
    crearNuevaLista,
  } = useListas();
  //Contexto local para almacenar el código de la lista que está seleccionada actualmente.
  const [listaSeleccionada, setListaSeleccionada] = useState(null);

  const mostrarDatosLista = (codigo) => {
    setListaSeleccionada(codigo);
    obtenerProductosPorLista(codigo);
  };

  const usarCrearLista = () => {
    setShowForm(true);
  };

  const usarCancelarCrear = () => {
    setShowForm(false);
    setNuevaListaNombre("");
  };

  const usarGuardarClick = () => {
    if (nuevaListaNombre.trim() !== "") {
      crearNuevaLista();
      setShowForm(false);
      setNuevaListaNombre("");
    }
  };

  return (
    <div className="contenedorListas">
      <div className="contenedorListasProductos">
        <div className="contenedorListadoListas">
          {listas ? (
            <div className="contenedorBotonLista">
              <button
                className="botonCrearLista"
                onClick={usarCrearLista}
              >
                Crear Lista
              </button>
              {/* Muestra el estado showForm del contexto */}
              {showForm && (
                <div className="ContenedorCrearLista">
                  <input
                    type="text"
                    value={nuevaListaNombre}
                    placeholder="Nombre lista"
                    onChange={(e) => setNuevaListaNombre(e.target.value)} 
                  />
                  <div className="contenedorBotonesCrearLista"> 
                  <button onClick={usarCancelarCrear}>Cancelar</button>
                  <button onClick={usarGuardarClick}>Guardar</button>
                  </div>
                  
                </div>
              )}
              {listas.map((lista) => (
                <div className="lista" key={lista.codigo}>
                  <div
                    className={`enlaceListas ${
                      lista.codigo === listaSeleccionada ? "selected" : ""
                    }`}
                    onClick={() => mostrarDatosLista(lista.codigo)}
                  >
                    <p className="nombreLista">{lista.nombre}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p>Cargando listas...</p>
          )}
        </div>

        {listaSeleccionada && (
          <ProductosLista codigoLista={listaSeleccionada} />
        )}
      </div>
    </div>
  );
};

export default ListadoListas;
