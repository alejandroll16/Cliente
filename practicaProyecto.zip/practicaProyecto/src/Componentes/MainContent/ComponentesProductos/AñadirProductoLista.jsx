import "./añadirProductoLista.css";
import React, { useState, useContext, useEffect } from "react";
import  useListas  from "../../Contextos/hooksContextos/useListas.jsx";

const AñadirProductoLista = ({ codigoProducto, cancelarAñadir, listas, confirmarAñadir }) => {
  const [listaSeleccionada, setListaSeleccionada] = useState(listas && listas.length > 0 ? listas[0].codigo : '');
  const { cantidad, setCantidad } = useListas();
  const [mensajeExito, setMensajeExito] = useState(null);
  const [mensajeError, setMensajeError] = useState(null);

  useEffect(() => {
    let timer;
    if (mensajeExito) {
      timer = setTimeout(() => {
        setMensajeExito(null);
        cancelarAñadir();
      }, 3000);
    }
    return () => clearTimeout(timer);
  }, [mensajeExito, cancelarAñadir]);

  const confirmarAñadirLista = async (codigoProducto, codigoLista) => {
    try {
      await confirmarAñadir(codigoProducto, codigoLista);
      setMensajeExito("¡El producto se ha añadido correctamente!");
      setCantidad(1); // Reiniciar la cantidad
    } catch (error) {
      setMensajeError("¡Error al añadir el producto a la lista!");
    }
  };

  return (
    <div className="confirmarAñadirLista">
      <div className="contenidoAñadirLista">
        <p>¿Seguro que quieres añadir este producto a la lista?</p>

        <select className="selectLista" value={listaSeleccionada} onChange={(e) => setListaSeleccionada(e.target.value)}>
          {listas && listas.map((lista) => (
            <option key={lista.codigo} value={lista.codigo}>{lista.nombre}</option>
          ))}
        </select>

        <div className="inputCantidad">
          <label>Cantidad: </label>
          <input type="number" value={cantidad} onChange={(e) => setCantidad(e.target.value)} />
        </div>
       
        <div className="botonesConfirmar">
          <button className="botonAñadirLista" onClick={() => confirmarAñadirLista(codigoProducto, listaSeleccionada)}>
            Añadir a lista
          </button>
          <button className="botonAñadirLista" onClick={() => {cancelarAñadir(); setCantidad(1)}}>
            Cancelar
          </button>
        </div>
        
        {mensajeExito && <p id="mensajeExito">{mensajeExito}</p>}
        {mensajeError && <p id="mensajeError">{mensajeError}</p>}
      </div>
    </div>
  );
};

export default AñadirProductoLista;
