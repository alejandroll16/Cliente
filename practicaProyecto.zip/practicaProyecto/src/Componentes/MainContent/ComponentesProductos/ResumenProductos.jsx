import React from 'react';
import "./resumen.css"

const ResumenProductos = ({ productos }) => {
  //Calcular el número de productos y el precio medio.
  const numeroProductos = productos.length;
  const precioTotal = productos.reduce((total, producto) => total + producto.precio, 0);
  const precioMedio = numeroProductos > 0 ? precioTotal / numeroProductos : 0;

  return (
    <div className='contenedorResumen'>
      <div className='resumen'>
        <h2>Cuadro resumen</h2>
        <p>Número de vehículos: {numeroProductos} </p>
        <p>Precio medio: {precioMedio.toFixed(2)} €</p>
      </div>
    </div>
  );
};

export default ResumenProductos;
