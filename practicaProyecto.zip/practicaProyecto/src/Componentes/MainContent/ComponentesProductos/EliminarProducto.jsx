import "./eliminarProducto.css";

//Definimos el componente que actuará como modal.
const EliminarProducto = ({
  //Pasamos como props las funciones creadas en ListaProductos.
  codigoProducto,
  cancelarEliminar,
  confirmarEliminar,
}) => {
  

  return (
    <div className="confirmarEliminar">
      <div className="contenidoEliminar">
        <p>¿Seguro que quieres eliminar este producto?</p>
        <div className="botonesConfirmar">
        <button className="botonEliminarProducto" onClick={() => confirmarEliminar(codigoProducto)}>
          Confirmar
        </button>
        <button className="botonEliminarProducto" onClick={cancelarEliminar}>Cancelar</button>
        </div>
        
      </div>
    </div>
  );
};

export default EliminarProducto;
