import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import  useProductos  from "../../Contextos/hooksContextos/useProductos.jsx";
import "./formularioCreaEdita.css";

const FormCreaMod = () => {
  const { codigo } = useParams(); //Seleccionamos de la url indicada el código.
  const navigate = useNavigate(); //Lo usamos para volver a la página de ListaProductos.
  const {
    datosFormulario,
    setDatosFormulario,
    erroresFormulario,
    setErroresFormulario,
    productos,
    setProductos,
    actualizarProducto,
    crearProducto,
    obtenerDatos,
    error,
    setError,
  } = useProductos();

  //Verificamos si existe el código para determinar si es una página de edición o creación.
  //Convierte el valor a booleano.
  //const esEdicion = Boolean(codigo); se podría hacer así pero vi esto buscando y lo vi útil.
  const esEdicion = !!codigo;

  useEffect(() => {
    //Si es una página de edición, nos cargará los datos del producto con el código proporcionado con useParams.
    if (esEdicion && productos) {
      const productoExistente = productos.find(
        (producto) => producto.codigo === codigo //Compara el código y si existe código cargará su información.
      );
      if (productoExistente) {
        setDatosFormulario(productoExistente);
      }
    } else {
      setDatosFormulario({
        nombre: "",
        precio: "",
        peso: "",
        imagen: "",
        descripcion_caract: "",
      });
    }
  }, [esEdicion, codigo, productos]);

  //Función para enviar los datos del formulario.
  const enviarDatos = async (event) => {
    event.preventDefault();

    //Validación de los campos del formulario.
    let hayError = false;
    const { nombre, precio, peso, imagen, descripcion_caract } =
      datosFormulario;
    const nuevosErrores = {};
    if (!nombre.trim()) {
      nuevosErrores.nombre = "¡El campo no puede estar vacío!";
      hayError = true;
    } else {
      nuevosErrores.nombre = "";
    }


    if (isNaN(precio) || !precio.toString().trim()) {
      nuevosErrores.precio = "¡Rellena el campo únicamente con números!";
      hayError = true;
    } else {
      nuevosErrores.precio = "";
    }

    if (isNaN(peso) || !peso.toString().trim()) {
      nuevosErrores.peso = "¡Rellena el campo únicamente con números!";
      hayError = true;
    } else {
      nuevosErrores.peso = "";
    }

    if (!imagen.trim()) {
      nuevosErrores.imagen = "¡La URL de la imagen no puede estar vacía!";
      hayError = true;
    } else {
      nuevosErrores.imagen = "";
    }

    if (!descripcion_caract.trim()) {
      nuevosErrores.descripcion_caract =
        "¡La descripción no puede estar vacía!";
      hayError = true;
    } else {
      nuevosErrores.descripcion_caract = "";
    }

    setErroresFormulario(nuevosErrores);

    //Si hay errores, no realiza el envío del formulario a la base de datos.
    if (hayError) {
      return;
    }

    //Verificar si estamos en modo de edición.
    try {
      //Construir el objeto de producto sin incluir el código ya que lo crea supabase.
      const nuevoProducto = {
        ...datosFormulario,
        precio: parseFloat(datosFormulario.precio),
        peso: parseFloat(datosFormulario.peso),
      };

      if (esEdicion) {
        //Si estamos en modo de edición, usar el código existente.
        await actualizarProducto(codigo, nuevoProducto);

        //Creamos una nueva lista copiando la anterior para así comparar los productos por su código y actualizar al que le hemos hecho cambios.
        const nuevosProductos = productos.map((producto) =>
          producto.codigo === codigo
            ? { ...producto, ...nuevoProducto }
            : producto
        );
        setProductos(nuevosProductos);
      } else {
        //Cuando es creación no necesitamos comparar ningún código y directamente se añade.
        await crearProducto(nuevoProducto);
      }

      //Nos envía a la página de lista de productos.
      navigate("/ListaProductos");
    } catch (error) {
      setError(error.message);
    }

    await obtenerDatos();
  };

  return (
    <div className="contenedorPrincipalFormulario">
      <div className="contenedorFormulario">
        {esEdicion ? <h2>Editar Producto</h2> : <h2>Crear Producto</h2>}
        <form onSubmit={enviarDatos}>
          <div className="form-group">
            <label>
              Nombre:
              <input
                type="text"
                value={datosFormulario.nombre}
                onChange={(e) =>
                  setDatosFormulario({
                    ...datosFormulario,
                    nombre: e.target.value,
                  })
                }
              />
              {erroresFormulario.nombre && (
                <p className="mensajeError">{erroresFormulario.nombre}</p>
              )}{" "}
            </label>
          </div>

          <div className="form-group">
            <label>
              Precio:
              <input
                type="number"
                value={datosFormulario.precio}
                onChange={(e) =>
                  setDatosFormulario({
                    ...datosFormulario,
                    precio: e.target.value,
                  })
                }
              />
              {erroresFormulario.precio && (
                <p className="mensajeError">{erroresFormulario.precio}</p>
              )}{" "}
            </label>
          </div>
          <div className="form-group">
            <label>
              Peso:
              <br />
              <input
                type="number"
                value={datosFormulario.peso}
                onChange={(e) =>
                  setDatosFormulario({
                    ...datosFormulario,
                    peso: e.target.value,
                  })
                }
              />
              {erroresFormulario.peso && (
                <p className="mensajeError">{erroresFormulario.peso}</p>
              )}{" "}
            </label>
          </div>

          <div className="form-group">
            <label>
              URL de la Imagen:
              <input
                type="text"
                value={datosFormulario.imagen}
                onChange={(e) =>
                  setDatosFormulario({
                    ...datosFormulario,
                    imagen: e.target.value,
                  })
                }
              />
              {erroresFormulario.imagen && (
                <p className="mensajeError">{erroresFormulario.imagen}</p>
              )}{" "}
            </label>
          </div>
          <div className="form-group">
            <label>
              Descripción del Producto:
              <input
                type="textarea"
                value={datosFormulario.descripcion_caract}
                onChange={(e) =>
                  setDatosFormulario({
                    ...datosFormulario,
                    descripcion_caract: e.target.value,
                  })
                }
              />
              {erroresFormulario.descripcion_caract && (
                <p className="mensajeError">
                  {erroresFormulario.descripcion_caract}
                </p>
              )}
            </label>
          </div>

          <button id="botonCreaEdit" type="submit">
            {esEdicion ? "Guardar Cambios" : "Crear Producto"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default FormCreaMod;
