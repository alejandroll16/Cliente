import {Fragment} from 'react';;
import Rutas from '../../Rutas/Rutas.jsx';
import "./mainContent.css"
const MainContent = () => {
  return (
    <Fragment>
      <div className='contenedorMain'>
        <Rutas/>
      </div>
    </Fragment>
  )
}

export default MainContent