import React, { useContext } from "react";
import { Link } from "react-router-dom";
import useProductos from "../../Contextos/hooksContextos/useProductos.jsx";
import ResumenProductos from "./ResumenProductos.jsx";
import "./listaProductos.css";
import EliminarProducto from "./EliminarProducto.jsx";
import AñadirProductoLista from "./AñadirProductoLista.jsx";
import useListas from "../../Contextos/hooksContextos/useListas.jsx";
import useUsuarios from "../../Contextos/hooksContextos/useUsuarios.jsx";

const ListaProductos = () => {
  const {
    productosFiltrados,
    eliminarProducto,
    productoAEliminar,
    setProductoAEliminar,
    mostrarEliminar,
    setMostrarEliminar,
    mostrarAñadirLista,
    setMostrarAñadirLista,
    productoALista,
    setProductoALista,
  } = useProductos();

  const { usuario, sesionIniciada } = useUsuarios();

  const { añadirProductoLista, listas } = useListas();

  //Función para mostrar la confirmación de eliminar de un producto por su código.
  const mostrarConfirmacionEliminar = (codigo) => {
    setProductoAEliminar(codigo);
    setMostrarEliminar(true); //Pasa a true y si muestra en pantalla.
  };

  //Al igual que con el modal para confirmar eliminar producto, hacemos lo mismo para añadir el producto a una lista, sigue la misma lógica, solo cambiamos los estados que tenemos en el contextoProductos
  const mostrarConfirmacionAñadirLista = (codigo) => {
    setProductoALista(codigo);
    setMostrarAñadirLista(true);
  };

  //Misma función que mostrar pero pasa a false y no haría falta un código.
  const cancelarEliminar = () => {
    setProductoAEliminar(null);
    setMostrarEliminar(false);
  };

  const cancelarAñadir = () => {
    setProductoALista(null);
    setMostrarAñadirLista(false);
  };

  //Función para confrmar que eliminamos un producto.
  const confirmarEliminar = async (codigo) => {
    if (codigo) {
      //Llamamos a la función de eliminarProducto del contexto.
      await eliminarProducto(codigo);
      setProductoAEliminar(null);
      setMostrarEliminar(false);
    }
  };

  const confirmarAñadirLista = async (codigoProducto, codigoLista) => {
    await añadirProductoLista(codigoProducto, codigoLista);
  };

  return (
    <div className="contenedorCesta">
      <div className="contenedorProductos">
        {productosFiltrados.map((producto, indice) => (
          <div className="tarjetaProducto" key={indice}>
            <div className="contenedorIzq">
              <h4 className="nombreProducto">{producto.nombre}</h4>
              <p className="precioProducto">Precio: {producto.precio} €</p>
              <img
                className="imgProducto"
                src={producto.imagen}
                alt={`Imagen de ${producto.nombre}`}
                style={{ maxWidth: "100%" }}
              />
            </div>
            <div className="contenedorDer">
              <p>{producto.descripcion_caract}</p>
              <p>Peso: {producto.peso}</p>
              <div className="contenedorBotones">
                {sesionIniciada && usuario.role === "administrador" && (
                  <Link
                    className="BotonProducto"
                    to={`/FormCreaMod/${producto.codigo}`}
                  >
                    Editar producto
                  </Link>
                )}

                {sesionIniciada && usuario.role === "administrador" && (
                  <button
                    className="BotonProducto"
                    onClick={() => mostrarConfirmacionEliminar(producto.codigo)}
                  >
                    Eliminar producto
                  </button>
                )}

                {sesionIniciada && (usuario.role === "administrador" || usuario.role === "authenticated") && (
                  <button
                    className="BotonProducto"
                    onClick={() =>
                      mostrarConfirmacionAñadirLista(producto.codigo)
                    }
                  >
                    Añadir a lista
                  </button>
                )}

              </div>
            </div>
          </div>
        ))}
      </div>

      <ResumenProductos productos={productosFiltrados} />

      {mostrarEliminar && (
        <EliminarProducto
          codigoProducto={productoAEliminar}
          cancelarEliminar={cancelarEliminar}
          confirmarEliminar={confirmarEliminar}
        />
      )}
      {mostrarAñadirLista && (
        <AñadirProductoLista
          codigoProducto={productoALista}
          cancelarAñadir={cancelarAñadir}
          confirmarAñadir={confirmarAñadirLista}
          listas={listas}
        />
      )}
    </div>
  );
};

export default ListaProductos;
