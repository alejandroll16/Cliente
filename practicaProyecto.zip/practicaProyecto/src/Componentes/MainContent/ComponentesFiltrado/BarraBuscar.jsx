import React, { useState } from 'react';
import "./barraBuscar.css"


//Recibe una función de búsqueda como prop.
const BarraBusqueda = ({ buscar }) => {
  //Estado local para almacenar la búsqueda.
  const [termino, setTermino] = useState('');

  //Función para actualizar el estado la búsqueda ingresada por el usuario.
  const usarBusqueda = (e) => {
    setTermino(e.target.value);
  };

  //Función para enviar la búsqueda al componente padre cuando se envía el formulario.
  const enviarBusqueda = (e) => {
    e.preventDefault();
    if (buscar) {
      buscar(termino);
    }
  };

  return (
    <form className='buscador' onSubmit={enviarBusqueda}>
      <label htmlFor="busqueda">Buscar vehículos: </label>
      <br />
      <input
        type="text"
        id="busqueda"
        value={termino}
        onChange={usarBusqueda}
        placeholder="Escribe tu búsqueda..."
      />
      <button className='botonBuscar' type="submit">Buscar</button>
    </form>
  );
};

export default BarraBusqueda;
