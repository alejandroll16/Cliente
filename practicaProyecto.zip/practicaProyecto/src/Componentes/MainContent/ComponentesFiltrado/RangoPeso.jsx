import React, { useState } from 'react';
import "./rangoPeso.css"  

const RangoPeso = ({ peso }) => {

  //Estado local para el rango de peso que seleccionemos.
  const [rangoPeso, setRangoPeso] = useState(0);

  //Función quue maneja la barra del rango.
  const cambioPeso = (event) => {
    //Convertimos el valor de la barra a entero.
    const nuevoPeso = parseInt(event.target.value, 10);  
    //Actualizamos el peso que será por el que se filtrará.
    setRangoPeso(nuevoPeso);
  };

  const filtrarPeso = () => {
    peso(rangoPeso);
  };

  return (
    <div className='contenedorPeso'> 
      <label>Peso: </label>
      <input className='barraRango'
        type="range"
        min={0}
        max={30000}
        value={rangoPeso}
        onChange={cambioPeso}  
      />
      <p>{` ${rangoPeso} Kg`}</p> 
      <button className='botonPeso' type="button" onClick={filtrarPeso}>
        Filtrar peso
      </button>
    </div>
  );
};

export default RangoPeso;
