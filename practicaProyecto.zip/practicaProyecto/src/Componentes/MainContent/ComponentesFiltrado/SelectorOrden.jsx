import React from 'react';
import "./selectorOrden.css"

//Función para seleccionar el orden de productos por el select.
const SelectorOrden = ({ orden }) => {
  const cambioOrden = (e) => {
    if (orden) {
      orden(e.target.value);
    }
  };

  return (
    <div className='contenedorSelect'>
      <label>Ordenar por:</label>
      <select id="campoOrden" onChange={cambioOrden}>
        
        <option value="nombre">Nombre</option>
        <option value="precio">Precio</option>
        <option value="peso">Peso</option>
      </select>
    </div>
  );
};

export default SelectorOrden;
