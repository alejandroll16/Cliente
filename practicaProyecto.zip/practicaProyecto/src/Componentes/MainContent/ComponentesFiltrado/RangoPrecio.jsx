import React, { useState } from 'react';
import "./rangoPrecio.css"

const RangoPrecio = ({ precio }) => {
  const [rangoPrecio, setRangoPrecio] = useState(0);

  //Funciona exactmanete igual a rango precio.
  const cambiarPrecio = (event) => {
    const nuevoPrecio = parseInt(event.target.value, 10);
    setRangoPrecio(nuevoPrecio);
  };

  const filtrarPrecio = () => {
    precio(rangoPrecio);
  };

  return (
    <div className='contenedorPrecio'>
      <label>Precio: </label>
      <input
        type="range"
        min={0}
        max={1500000}
        value={rangoPrecio}
        onChange={cambiarPrecio}
      />
      <p>{`${rangoPrecio}  €`}</p>
      <button className='botonPrecio' type="button" onClick={filtrarPrecio}>
        Filtrar precio
      </button>
    </div>
  );
};


export default RangoPrecio;
