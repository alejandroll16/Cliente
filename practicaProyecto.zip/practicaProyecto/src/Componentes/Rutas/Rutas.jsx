import React, { Fragment } from "react";
import { Routes, Route } from "react-router-dom";
import Inicio from "../../Componentes/Pagina/Inicio.jsx";
import Error from "../../Componentes/Pagina/Error.jsx";
import CestaProductos from "../../Componentes/Pagina/CestaProductos.jsx";
import CrearProducto from "../../Componentes/Pagina/CrearProducto.jsx";
import EditarProducto from "../../Componentes/Pagina/EditarProducto.jsx";
import Listas from "../../Componentes/Pagina/Listas.jsx";
import CrearUsuario from "../Pagina/CrearUsuario.jsx";

const Rutas = () => {
  return (
    <Fragment>
      <Routes>
        <Route path='/' element={<Inicio />} />
        <Route path='/ListaProductos' element={<CestaProductos />} />
        <Route path='/FormCreaMod' element={<CrearProducto />} />  
        <Route path='/FormCreaMod/:codigo' element={<EditarProducto />} /> 
        <Route path='*' element={<Error />} />
        <Route path='/ListadoListas' element={<Listas/>} /> 
        <Route path='/FormCrearUsuario' element={<CrearUsuario/>} /> 


      </Routes>
    </Fragment>
  );
};

export default Rutas;
