import React, { createContext, useState, useEffect, useContext } from 'react';
import { supabaseConexion } from '../../Config/supabase.js';  // Importa la conexión a Supabase desde otro archivo.
import useUsuarios from './hooksContextos/useUsuarios.jsx';

const contextListas = createContext();

const ContextoListas = ({ children }) => {

  const {usuario} = useUsuarios();
  const [listas, setListas] = useState(null);  //Estado para almacenar la lista de listas.
  const [productosPorLista, setProductosPorLista] = useState(null);  //Estado para almacenar productos por lista.
  const [error, setError] = useState(null);  //Estado para manejar errores.
  const [showForm, setShowForm] = useState(false);  //Estado para mostrar/ocultar un formulario.
  const [nuevaListaNombre, setNuevaListaNombre] = useState('');  //Estado para almacenar el nombre de una nueva lista.
  const [showEliminarProductoLista, setShowEliminarProductoLista] = useState(false);  //Estado para mostrar/ocultar la eliminación de un producto.
  const [productoAEliminarLista, setProductoAEliminarLista] = useState(null);  //Estado para almacenar el producto a eliminar.
  const [cantidad, setCantidad] = useState(1);  //Estado para almacenar la cantidad de productos.

  //Función para obtener los datos de las listas desde Supabase, usamos prácticamente la misma lógica que en obtenerProductos.
  const obtenerDatosListas = async () => {
    try {
      const { data, error } = await supabaseConexion.from('PROYECTO_lista').select('*');
      if (error) {
        throw new Error(`Error al obtener los datos de Supabase: ${error.message}`);
      }
      setListas(data);
    } catch (error) {
      setError(error.message);
    }
  };

  //Función asincrónica para obtener productos por lista desde Supabase.
  const obtenerProductosPorLista = async (codigoLista) => {
    try {
      //Hacemos una consulta y obtenemos todas las columnas de la tabla de productos y la cantidad, filtrando por el codigoLista que pasamos como argumento.
      const { data, error } = await supabaseConexion
        .from('PROYECTO_lista-producto')
        .select('tablaProducto:PROYECTO_productos(*), cantidadProductos')
        .eq('codigo_lista', codigoLista);

      if (error) {
        throw new Error(`Error al obtener los productos de la lista: ${error.message}`);
      }

      setProductosPorLista(data);
    } catch (error) {
      setError(error.message);
    }
  };

  //Función para añadir un producto a la lista.
  const añadirProductoLista = async (codigoProducto, codigoLista) => {
    try {
      if (!codigoLista || !codigoProducto) {
        return;
      }

      //De lista-productos seleccionamos la columna de cantidad y filtramos para obtener codigoLista y codigoProducto pasado por argumentos, para saber si ese producto está ne la lista.
      const { data: productosEnLista, error } = await supabaseConexion
        .from('PROYECTO_lista-producto')
        .select('cantidadProductos')
        .eq('codigo_lista', codigoLista)
        .eq('codigo_productos', codigoProducto);

      if (error) {
        throw new Error(`Error al verificar productos en la lista: ${error.message}`);
      }

      //Comprobamos si productosEnLista esta en la lista, si es así sumamos el valor del estado cantidad con el valor cantidadActual para aumentar la cantidad en la lista de ese producto.
      if (productosEnLista && productosEnLista.length > 0) {
        const cantidadActual = parseFloat(productosEnLista[0].cantidadProductos) || 0;
        await supabaseConexion
          .from('PROYECTO_lista-producto')
          .update({ cantidadProductos: cantidadActual + parseFloat(cantidad) })
          .eq('codigo_lista', codigoLista)
          .eq('codigo_productos', codigoProducto);
      } else {
        //Si por otro lado no está en la lista añadimos el producto a la lista con el estado predeterminado que es 1.
        await supabaseConexion
          .from('PROYECTO_lista-producto')
          .insert({
            codigo_lista: codigoLista,
            codigo_productos: codigoProducto,
            cantidadProductos: cantidad,
          });
      }
    } catch (error) {
      setError(error.message);
    }
  };

  // Función asincrónica para crear una nueva lista.
  const crearNuevaLista = async () => {
    try {
      const { data, error } = await supabaseConexion.from('PROYECTO_lista').insert([
        {
          nombre: nuevaListaNombre,
        },
      ]);

      if (error) {
        // Manejar el error si es necesario.
      } else {
        obtenerDatosListas();  // Actualiza la lista después de la creación exitosa.
      }
    } catch (error) {
      setError(error.message);
    }
  };

  //Función para eliminar un producto de la lista, seguímos lógica de eliminar producto de la listaProductos pero le pasamos el codigo lista por argumento para filtrar tando el código de producto como el de lista.
  const eliminarProductoLista = async (codigoProducto, codigoLista) => {
    try {
      if (!codigoProducto || !codigoLista) {
        return;
      }

      const { data, error } = await supabaseConexion
        .from('PROYECTO_lista-producto')
        .delete()
        .eq('codigo_productos', codigoProducto)
        .eq('codigo_lista', codigoLista);

      if (error) {
        throw new Error(`Error al eliminar el producto en Supabase: ${error.message}`);
      }

      await obtenerProductosPorLista(codigoLista);  //Actualiza la lista de productos después de eliminar el producto.

    } catch (error) {
      setError(error.message);
    }
  };

  



  
  useEffect(() => {
    obtenerDatosListas();
  }, [usuario]);

  const contextValueListas = {
    listas,
    setListas,
    error,
    setError,
    obtenerDatosListas,
    productosPorLista,
    obtenerProductosPorLista,
    añadirProductoLista,
    showForm,
    setShowForm,
    nuevaListaNombre,
    setNuevaListaNombre,
    crearNuevaLista,
    eliminarProductoLista,
    showEliminarProductoLista,
    setShowEliminarProductoLista,
    productoAEliminarLista,
    setProductoAEliminarLista,
    cantidad,
    setCantidad,
  };

  return (
    <contextListas.Provider value={contextValueListas}>
      {children}
    </contextListas.Provider>
  );
};

export default ContextoListas;
export { contextListas };
