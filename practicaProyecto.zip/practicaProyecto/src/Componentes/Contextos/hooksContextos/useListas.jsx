import { useContext } from "react";
import { contextListas } from "../ContextoListas.jsx";

const useListas = () => {
  const contexto = useContext(contextListas);
  return contexto;
};

export default useListas;