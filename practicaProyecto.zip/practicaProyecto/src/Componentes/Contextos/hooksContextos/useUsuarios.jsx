import { useContext } from "react";
import { contextUsuarios } from "../ContextoUsuarios.jsx";

const useUsuarios = () => {
  const contexto = useContext(contextUsuarios);
  return contexto;
};

export default useUsuarios;