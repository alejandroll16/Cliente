import { useContext } from "react";
import { context } from "../ContextoProductos";

const useProductos = () => {
  const contexto = useContext(context);
  return contexto;
};

export default useProductos;