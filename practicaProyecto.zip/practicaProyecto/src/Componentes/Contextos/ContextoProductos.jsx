import React, { createContext, useState, useEffect } from 'react';
//Importamos la conexión a supabase.
import { supabaseConexion } from '../../Config/supabase.js';
import { ordenarProductos, filtrarProductos } from '../../bibliotecas/biblioteca.js';

const context = createContext();

const ContextoProductos = ({ children }) => {

  //Estados contexto.
  const [datosFormulario, setDatosFormulario] = useState({
    nombre: "",
    precio: "",
    peso: "",
    imagen: "",
    descripcion_caract: "",
  });
  const [erroresFormulario, setErroresFormulario] = useState({
    nombre: "",
    precio: "",
    peso: "",
    imagen: "",
    descripcion_caract: "",
  });
  const [nuevoProducto, setNuevoProducto] = useState('');
  const [productos, setProductos] = useState(null);
  const [cargar, setCargar] = useState(true);
  const [errorGeneral, setErrorGeneral] = useState(null);
  const [error, setError] = useState(null);
  const [criterioOrden, setCriterioOrden] = useState('nombre');
  const [orden, setOrden] = useState(1);
  const [terminoBusqueda, setTerminoBusqueda] = useState('');
  const [rangoPrecio, setRangoPrecio] = useState([50000000]);
  const [rangoPeso, setRangoPeso] = useState([500000]);
  const [productoAEliminar, setProductoAEliminar] = useState(null);
  const [mostrarEliminar, setMostrarEliminar] = useState(false);
  const [productoALista, setProductoALista] = useState(null);
  const [mostrarAñadirLista, setMostrarAñadirLista] = useState(false);

  //Obtenemos los datos de la base de datos de manera asíncrona, recogemos errores con try catch
  const obtenerDatos = async () => {
    try {
      //Consulta a la base de datos para obtener la tabla en cuestión.
      const { data, error } = await supabaseConexion.from('PROYECTO_productos').select('*');
      if (error) {
        throw new Error(`Error al obtener los datos de Supabase: ${error.message}`);
      }
      setProductos(data);
    } catch (error) {
      setError(error.message);
    }
  };

  //Función para cambiar el orden de la lista de productos.
  const cambiarOrden = (criterio) => {
    //Si criterio actual es igual a criterioOrden se cambia el orden si no se pone a uno que es de manera ascendente.
    setOrden((ordenAnterior) => (criterio === criterioOrden ? -ordenAnterior : 1));
    setCriterioOrden(criterio);
  };

  //Función para establecer el término de búsqueda.
  const filtrarProductoActual = (termino) => {
    setTerminoBusqueda(termino);
  };

  //Función que filtra y ordena los productos aplicando los criterios.
  //Si no hay producto devuelve un array vacío para evitar errores miestras carga.
  const aplicarFiltros = () => {
    if (!productos) {
      return [];
    }

    //Hacemos uso de la función de filtrar en la biblioteca, en función de el termino de busqueda.
    const productosFiltrados = filtrarProductos(productos, terminoBusqueda);

    //Filtramos productos por precio y ppeso y se guardan en la lista de productosFiltradosPrecioPeso.
    const productosFiltradosPrecioPeso = productosFiltrados.filter(
      (producto) =>
        producto.precio <= rangoPrecio &&
        producto.peso <= rangoPeso
    );

    //Ordenamos la lista en función de lo anterior con la función importada de biblioteca.
    return ordenarProductos(productosFiltradosPrecioPeso, criterioOrden, orden);
  };

  //Función para actualizar un producto en la base de datos.
  const actualizarProducto = async (codigo, nuevoProducto) => {
    try {
      //Funcionalidad obtenerDatos('PROYECTO_productos');parecida a obtenerProducto, modificando la consulta.
      const { data, error } = await supabaseConexion
        .from('PROYECTO_productos')
        .update(nuevoProducto)
        .eq('codigo', codigo);

      if (error) {
        throw new Error(`Error al actualizar el producto en Supabase: ${error.message}`);
      }

    } catch (error) {
      setErrorGeneral(error.message);
    }
  };
  //Función para crear un nuevo producto en la base de datos.
  const crearProducto = async (nuevoProducto) => {
    try {
      //Igual que actualizar, modificamos la consulta.
      const { data, error } = await supabaseConexion
        .from('PROYECTO_productos')
        .insert(nuevoProducto);

      if (error) {
        console.error(`Error al crear el producto en Supabase: ${error.message}`);
      }
    } catch (error) {
      setErrorGeneral(error.message);
    }
  };

  const eliminarProducto = async (codigo) => {
    try {
      const { data, error } = await supabaseConexion
        .from('PROYECTO_productos')
        .delete()
        .eq('codigo', codigo);

      if (error) {
        throw new Error(`Error al eliminar el producto en Supabase: ${error.message}`);
      }
      //Lo anterior igual a actualizarProducto.
      //Además, si se elimina correctamente actualizamos el estado local, filtrando y eliminando el producto con el que concida el código, así actalizamos la lista al eliminar sin cargar de nuevo la base de datos.
      setProductos((prevProductos) =>
        prevProductos.filter((producto) => producto.codigo !== codigo)
      ); obtenerDatos('PROYECTO_productos');


    } catch (error) {
      setErrorGeneral(error.message);
    }
  };


  //Se ejecuta una sola vez al montar.
  useEffect(() => {
    obtenerDatos();
  }, []);

  const contextValue = {
    datosFormulario,
    setDatosFormulario,
    erroresFormulario,
    setErroresFormulario,
    productos,
    setProductos,
    cargar,
    error: errorGeneral,
    setError: setErrorGeneral,
    cambiarOrden,
    filtrarProductos: filtrarProductoActual,
    productosFiltrados: aplicarFiltros(),
    actualizarProducto,
    crearProducto,
    setOrden,
    eliminarProducto,
    nuevoProducto,
    obtenerDatos,
    rangoPrecio,
    setRangoPrecio,
    rangoPeso,
    setRangoPeso,
    productoAEliminar,
    setProductoAEliminar,
    mostrarEliminar,
    setMostrarEliminar,
    mostrarAñadirLista,
    setMostrarAñadirLista,
    productoALista,
    setProductoALista,

  };

  return (
    <context.Provider value={contextValue}>
      {children}
    </context.Provider>
  );
};

export default ContextoProductos;
export { context };
