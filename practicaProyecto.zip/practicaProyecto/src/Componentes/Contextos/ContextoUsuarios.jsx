import React, { useState, useEffect, createContext } from "react";
import { supabaseConexion } from "../../Config/supabase.js";
import { useNavigate } from "react-router-dom";

const contextUsuarios = createContext();

const ContextoUsuarios = ({ children }) => {
  //Usamos el hook de react navigate para desplazarnos entre las rutas.
  const navigate = useNavigate();

  //Datos iniciales de correo y contraseña para resetear cuando sea necesario.
  const datosSesionInicial = {
    email: "",
    password: "",
  };

  const sesionInicial = false;
  const usuarioInicial = {};
  const errorUsuarioInicial = "";

  const [datosSesion, setDatosSesion] = useState(datosSesionInicial);
  const [usuario, setUsuario] = useState(usuarioInicial);
  const [errorUsuario, setErrorUsuario] = useState(errorUsuarioInicial);
  const [sesionIniciada, setSesionIniciada] = useState(sesionInicial);
  const [mostrarIniciarSesion, setMostrarIniciarSesion] = useState(false);

  //Función para crear cuenta de usuario.
  const crearCuenta = async () => {
    //try catch para capturar errores.
    try {

      //Usamos auth.signUp para añadir un usuario a auth de supabase pasando mediante el estado datos sesión un email y una contraseña.
      const { data, error } = await supabaseConexion.auth.signUp({
        email: datosSesion.email,
        password: datosSesion.password,
      });

      if (error) {
        throw error;
      } else {
      }
    } catch (error) {
      setErrorUsuario(error.message);
    }
  };

  //Función para iniciar sesión, en este caso usamos signInWithPassword, esto comprobará que existe ese email y contraseña y si es así iniciará sesión.
  const iniciarSesion = async () => {
    try {
      const { data, error } = await supabaseConexion.auth.signInWithPassword({
        email: datosSesion.email,
        password: datosSesion.password,
      });

      if (error) {
        throw error;
      }
    } catch (error) {
      setErrorUsuario(error.message);
    }
  };

  //Actualiza los datos de sesión en caso de que haya cambios en el estado de datosSesión, es decir, cerrar o iniciar sesión, true o false.
  const actualizarDato = (e) => {
    const { name, value } = e.target;
    setDatosSesion({ ...datosSesion, [name]: value });
  };

  //Función para obtener los datos del usuario que tenga la sesión iniciada, haciendo uso de getUser.
  const obtenerUsuario = async () => {
    try {
      const { data, error } = await supabaseConexion.auth.getUser();

      if (error) {
        throw error;
      }
      //Añadimos estos datos de usuario al estado de usuario.
      setUsuario(data.user);
    } catch (error) {
      setErrorUsuario(error.message);
      navigate("/");
    }
  };

  //Función para cerrar la cuenta
  const cerrarSesion = async () => {
    try {
      //Se cierra la sesión haciendo uso de signOut.
      await supabaseConexion.auth.signOut();

      navigate("/");
      //Ponemos los datosSesion iniciales para que no se queden guardados los del usuario anterior.
      setDatosSesion(datosSesionInicial);
      //Lo mismo para el estado de la sesión.
      setSesionIniciada(false);
    } catch (error) {
      setErrorUsuario(error.message);
    }
  };

  //A ver, aquí he colocado suscripción dentro del useEffect para que cuando cambie de usuario sin hacer F5 se me modifiquen los botones y enlaces que se ocultan o se muestran según el rol.
  //Es decir cuando cambie la session se actualizan los componentes.
  useEffect(() => {
    const suscripcion = supabaseConexion.auth.onAuthStateChange(
      (event, session) => {
        if (session) {
          navigate("/");
          setSesionIniciada(true);
          obtenerUsuario();
        } else {
          navigate("/");
          setSesionIniciada(false);
        }
      }
    );

  }, []);

  const contextValue = {
    crearCuenta,
    actualizarDato,
    mostrarIniciarSesion,
    setMostrarIniciarSesion,
    iniciarSesion,
    cerrarSesion,
    sesionIniciada,
    usuario,
  };

  return (
    <contextUsuarios.Provider value={contextValue}>
      {children}
    </contextUsuarios.Provider>
  );
};

export default ContextoUsuarios;
export { contextUsuarios };
