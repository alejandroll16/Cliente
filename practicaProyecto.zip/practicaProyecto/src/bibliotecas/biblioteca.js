const ordenarProductos = (productos, criterio, orden) => {
  //Utilizamos slice() para crear una copia del array de productos y no modificar el original.
  return productos.slice().sort((a, b) => {
    //Obtenemos los valores a comparar según el criterio especificado.
    const valorA = a[criterio];
    const valorB = b[criterio];

    //Comprobamos si los valores son cadenas de texto para ordenar alfabéticamente.
    if (typeof valorA === 'string' && typeof valorB === 'string') {
      //Utilizamos localeCompare para comparar cadenas de texto de manera adecuada.
      return orden * valorA.localeCompare(valorB);
    } else {
      //Si no son cadenas de texto, asumimos que son valores numéricos y los comparamos directamente.
      return orden * (valorA - valorB);
    }
  });
};

const filtrarProductos = (productos, terminoBusqueda) => {
  //Utilizamos filter para mantener solo los productos que cumplen con la condición.
  return productos.filter((producto) =>
    //Convertimos tanto el nombre del producto como el término de búsqueda a minúsculas para hacer la comparación insensible a mayúsculas.
    producto.nombre.toLowerCase().includes(terminoBusqueda.toLowerCase())
  );
};

export { ordenarProductos, filtrarProductos };
