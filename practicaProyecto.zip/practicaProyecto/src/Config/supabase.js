import { createClient } from "@supabase/supabase-js";

const supabaseConexion = createClient(
  "https://ggwqsvyooyinduvsfdka.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imdnd3Fzdnlvb3lpbmR1dnNmZGthIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDY4OTQ4MTksImV4cCI6MjAyMjQ3MDgxOX0.0dCKRZicvaTfJwiwG4_6duANV9hbGKGDJ7J33uq_nNs",
);

export { supabaseConexion };